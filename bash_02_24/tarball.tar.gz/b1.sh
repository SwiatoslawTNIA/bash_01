#!/bin/bash
#Testing the shtool:
shtool platform
shtool --version

